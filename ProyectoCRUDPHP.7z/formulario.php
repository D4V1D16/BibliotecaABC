
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Formulario</title>
        <link rel="stylesheet" href="styles.css">
    </head>
    <body>
        <main>
            <h1>Formulario</h1>
            <form class="Formulario" method="post" action="index.php">
                <label for = "id" class="lblInput">Id(Para modificar usuarios)</label><br>
                <input id="id" name="id" class="input" type="number"><br>
                <label for="nombre" class="lblInput">Nombre</label><br>
                <input id="nombre" name="nombre" class="input" type="text"><br>
                <label for="apellido" class="lblInput">Apellido</label><br>
                <input id="apellido" name="apellido" class="input" type="text"><br>
                <label for="email" class="lblInput">Email</label><br>
                <input id="email" name="email" class="input" type="email"><br>
                <label for="telefono" class="lblInput">Telefono</label><br>
                <input id="telefono" name="telefono" class="input" type="tel"><br>
                <label for="direccion" class="lblInput">Direccion</label><br>
                <input id="direccion" name="direccion" class="input" type="text"><br>
                <div class="buttonsCrud">
                    
                    <button type="submit" class="button" name="agregar">Agregar</button>
                    <button type="submit" class="button" name="eliminar">Eliminar Usuario</button>
                    <button type="submit" class="button" name="modificar">Modificar Usuario</button>
                    <button type="submit" class="button" name="mostrar">Mostrar</button>


                </div>
            </form>
        </main>
    </body>
</html> 
<?php

    include 'agregar.php';
    include 'borrar.php';
    include 'modificar.php';
    include 'mostrar.php';


    mysqli_close($conection);


?>