<?php

    $conection = new mysqli('localhost','root','','uninpahu');

    if(!$conection){
        die(mysqli_error($conection));
    } 

?>