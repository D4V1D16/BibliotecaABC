<?php

    include 'conectar.php';



    if(isset($_POST['agregar'])){
        $id = $_POST['id'];
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $email = $_POST['email'];
        $telefono = $_POST['telefono'];
        $direccion = $_POST['direccion'];


        $sql = "INSERT INTO usuarios (nombre,apellidos,correo,telefono,direccion) VALUES ('$nombre','$apellido','$email','$telefono','$direccion');";
        $result = mysqli_query($conection,$sql);
        if($result){
            echo "Usuario Ingresado con exito";
        } else{
            die(mysqli_error($conection));
        }
    }


?>