<?php


    include 'conectar.php';


    if(isset($_POST['eliminar'])){
        $nombre = $_POST['nombre'];

        $sql = "DELETE FROM usuarios WHERE nombre = '$nombre';";

        $result = mysqli_query($conection, $sql);

        if($result){
            echo "El usuario se ha eliminado exitosamente";
        } else{
            die(mysqli_error($conection));
        }
    }



?>