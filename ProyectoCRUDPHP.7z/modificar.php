<?php

    include 'conectar.php';

    if(isset($_POST['modificar'])){
        $id = $_POST['id'];
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $email = $_POST['email'];
        $telefono = $_POST['telefono'];
        $direccion = $_POST['direccion'];

        $sql = "UPDATE usuarios SET nombre = '$nombre', apellidos = '$apellido', correo = '$email', telefono = '$telefono', direccion = '$direccion' WHERE id = $id;";

        $result = mysqli_query($conection,$sql);

        if($result){
            echo "El usuario ha sido modificado correctamente";
        } else{
            die(mysqli_error($conection));
        }
    }


?>